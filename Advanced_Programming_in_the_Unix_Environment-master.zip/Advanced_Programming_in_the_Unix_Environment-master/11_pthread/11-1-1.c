//#include "apue.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>

pthread_t	ntid;

void printids(const char *s)
{
	pid_t		pid;
	pthread_t	tid;

	pid = getpid();
	tid = pthread_self();
	printf("%s pid %u tid %u (0x%x)\n", s, (unsigned int)pid, (unsigned int)tid, (unsigned int)tid);
}

void *thr_fn(void *arg)
{
	int i = 0;

	while (1) {
		sleep(5);
		printf("%d: new thread...\n", i);
		if (i > 10)
			//break;	//main processは終わらない
			exit(0);	//main processまで終わる	
		i++;
	}

	return ((void*)0);
}

int main(void)
{
	int	err;
	int i = 0;

	err = pthread_create(&ntid, NULL, thr_fn, NULL);
	if (err != 0)
		//err_quit("can't create thread: %d\n", strerror(err));
		printf("can't create thread: %d\n", strerror(err));

	sleep(1);

	while (1) {
		sleep(1);
		printf("%d: main process...\n", i);
		i++;
	}

	exit(0);
}
