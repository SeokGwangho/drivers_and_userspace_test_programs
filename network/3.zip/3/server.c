/*
	sender.c (sender)
	NON BLOCK
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>

int port = 6789;

int main()
{
    int socket_descriptor;
    int iter = 0;

    ssize_t sendto_rc;
    int close_rc;

    char buf[80];
    struct sockaddr_in address;
    struct hostent *hostbyname;

    //Translate a host name to IP address
    hostbyname = gethostbyname("192.168.11.2");
    if(hostbyname == NULL)
    {
        perror("Get host by name failed");
        exit(errno);
    }

   
    bzero(&address, sizeof(address)); // empty data structure
    address.sin_family = AF_INET;

    memcpy(&address.sin_addr.s_addr, hostbyname->h_addr, sizeof(address.sin_addr.s_addr));

    //print the Server IP
    printf("The Server IP is %s\n", inet_ntoa(*(struct in_addr*)hostbyname->h_addr));    

    //address.sin_addr.s_addr = inet_addr("127.0.0.1");
    address.sin_port = htons(port);

   
    socket_descriptor = socket(AF_INET, SOCK_DGRAM, 0);
    if(socket_descriptor == -1)
    {
        perror("socket call failed");
        exit(errno);
    }

    //Loop 200 times (a nice round number ) sending data
    for(iter = 0; iter <= 200; iter++) {
        sprintf(buf, "data packet with id %d\n", iter);
        sendto_rc = sendto(socket_descriptor, buf, sizeof(buf), 0, (struct sockaddr *)&address, sizeof(address));
        if(sendto_rc == -1)
        {
            perror("sendto call failed");
            exit(errno);
        }
        
        sleep(1);
    }    

   
    sprintf(buf, "stop\n");
    sendto_rc = sendto(socket_descriptor, buf, sizeof(buf), 0, (struct sockaddr *)&address, sizeof(address)); //address is the target of the message send
    if(sendto_rc == -1)
    {
        perror("sendto  STOP call failed");
        exit(errno);
    }
    

    //Most people don''t bother to check the return code returned by the close function
    close_rc = close (socket_descriptor);
    if(close_rc == -1)
    {
        perror("close call failed");
        exit(errno);
    }

    printf("Message Sent, Terminating\n");
    return 0;
}
