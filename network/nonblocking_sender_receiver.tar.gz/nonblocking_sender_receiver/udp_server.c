/*
	server.c (sender)
*/
#include<sys/types.h>
#include<sys/socket.h>
#include<unistd.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<netdb.h>
#include<stdarg.h>
#include<string.h>


int port = 6789;

int main(int argc, char **argv)
{
    int socket_descriptor;
    long int i = 0;
    ssize_t sendto_rc;
    int close_rc;
    char buf[80];
    struct sockaddr_in address;
    struct hostent *target;

    target = gethostbyname("192.168.11.5");
    if(target == NULL) {
        perror("get host by name failed");
        exit(errno);
    }

    bzero(&address, sizeof(address));
    address.sin_family = AF_INET;
    memcpy(&address.sin_addr.s_addr, target->h_addr, sizeof(address.sin_addr.s_addr));

    printf("the target(client) ip is %s\n", inet_ntoa(*(struct in_addr*)target->h_addr));    

    //address.sin_addr.s_addr = inet_addr("127.0.0.1");
    address.sin_port = htons(port);
   
    socket_descriptor = socket(AF_INET, SOCK_DGRAM, 0);
    if(socket_descriptor == -1) {
        perror("socket call failed");
        exit(errno);
    }

    //sending data
    while(1) {
	i++;
        sprintf(buf, "data packet with id %ld\n", i);
        sendto_rc = sendto(socket_descriptor, buf, sizeof(buf), 0, (struct sockaddr *)&address, sizeof(address));
        if(sendto_rc == -1) {
            perror("sendto failed");
            exit(errno);
        }
        
        //sleep(1);
	if (9999999 == i)
		break;
    }    

   
    sprintf(buf, "stop\n");
    sendto_rc = sendto(socket_descriptor, buf, sizeof(buf), 0, (struct sockaddr *)&address, sizeof(address));
    if(sendto_rc == -1) {
        perror("sendto  STOP call failed");
        exit(errno);
    }
    

    close_rc = close(socket_descriptor);
    if(close_rc == -1) {
        perror("close call failed");
        exit(errno);
    }

    printf("Message Sent, Terminating\n");
    return 0;
}
