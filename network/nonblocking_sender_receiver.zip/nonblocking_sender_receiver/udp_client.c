/*
	client.c (sender)
*/
#include<sys/types.h>
#include<sys/socket.h>
#include<unistd.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<netdb.h>
#include<stdarg.h>
#include<string.h>
#include<signal.h>

int port = 6789;
int flag;

void sigalrm_fn(int sig)
{  
    printf("%s: is time!\n", __func__);  
    flag = 1;
 
    return;  
}  

int main(int argc, char **argv)
{
    int socket_descriptor;
    long int i = 0;
    ssize_t sendto_rc;
    int close_rc;
    char data[80];
    struct sockaddr_in address;
    struct hostent *target;

    if (argc != 3) {
	printf("[Client]usage: udp_server server_ip seconds\n");
	exit(-1);
    }

    target = gethostbyname(argv[1]);
    if(target == NULL) {
        perror("[Clinet]get host by name failed");
        exit(errno);
    }

    bzero(&address, sizeof(address));
    address.sin_family = AF_INET;
    memcpy(&address.sin_addr.s_addr, target->h_addr, sizeof(address.sin_addr.s_addr));

    signal(SIGALRM, sigalrm_fn);
    alarm(atoi(argv[2]));
    printf("[Client]the target server ip is %s, time is %ss\n", inet_ntoa(*(struct in_addr*)target->h_addr), argv[2]);    

    address.sin_port = htons(port);
   
    socket_descriptor = socket(AF_INET, SOCK_DGRAM, 0);
    if(socket_descriptor == -1) {
        perror("socket call failed");
        exit(errno);
    }


    //sending data
    while(1) {
	i++;
        sprintf(data, "data packet with id %ld", i);

        sendto_rc = sendto(socket_descriptor, data, sizeof(data), 0, (struct sockaddr *)&address, sizeof(address));
        if(sendto_rc == -1) {
            perror("sendto failed");
            exit(errno);
        }
        
        //sleep(1);
	if (1 == flag)
		break;
    }    

   
    sprintf(data, "stop\n");
    sendto_rc = sendto(socket_descriptor, data, sizeof(data), 0, (struct sockaddr *)&address, sizeof(address));
    if(sendto_rc == -1) {
        perror("sendto  STOP call failed");
        exit(errno);
    }
    

    close_rc = close(socket_descriptor);
    if(close_rc == -1) {
        perror("close call failed");
        exit(errno);
    }

    printf("[Client]client terminating\n");
    return 0;
}
