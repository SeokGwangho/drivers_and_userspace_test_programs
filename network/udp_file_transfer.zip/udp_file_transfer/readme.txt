1. build：
    gcc udp_server.c -o udp_server
    gcc udp_client.c -o udp_client


2. udp_server/udp_client　と同じDirectに転送したいFileを置く(ServerにFileを置く)


3.Terminal 1で、先にServerを実行：
    sgh@sgh-OptiPlex-9020:~/Documents/sgh_doc/network/udp_file_transfer$ ./udp_server


4.Terminal 2で、Clientを実行(server ip, port numberをパラメータとして指定)し、File Nameを入力：

    そうすれば、ClientからServerにFile Nameを教えて、ServerからそのfileをClientに発送し始める。ClientはそのFileを別のNameで保存する

    sgh@sgh-OptiPlex-9020:~/Documents/sgh_doc/network/udp_file_transfer$ ./udp_client
    [Client]please input the file name: test.mp3

    
