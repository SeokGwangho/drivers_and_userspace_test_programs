/*************************************************************************
 * client.c
 *
 * example:
 * 	./client <server ip> <port number>
 ************************************************************************/
#include<sys/types.h>
#include<sys/socket.h>
#include<unistd.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<netdb.h>
#include<stdarg.h>
#include<string.h>


#define SERVER_PORT		8000
#define BUFFER_SIZE		1024
#define FILE_NAME_MAX_SIZE	512

/* package header */
typedef struct {
	long int id;
	int buf_size;
	unsigned int crc32val;	/* buffer毎のcrc32値 */
	int err_flag;
} pack_info_t;

/* receive package */
struct recv_pack {
	pack_info_t head;
	char buf[BUFFER_SIZE];
} data;


/*----------------------crc32----------------------*/
static unsigned int crc_table[256];
static void init_crc_table(void);
static unsigned int crc32(unsigned int crc, unsigned char * buffer, unsigned int size);
unsigned int crc = 0xffffffff;	/* 最初に渡される値は固定にする。もし発送側がこの値を使ってCRC計算するとしたら、当然受信側もこの値で計算すべき */

/**************************************************
 CRC表を初期化
 32BitのCRC表を生成する
 CRC表を生定義して、参照しても良いが、256個もあるので、紛らわしいので生成した方が楽かも…
***************************************************/
static void init_crc_table(void)
{
	unsigned int c;
	unsigned int i, j;
	
	for (i = 0; i < 256; i++) {
		c = (unsigned int)i;
		for (j = 0; j < 8; j++) {
			if (c & 1)
				c = 0xedb88320L ^ (c >> 1);
			else
				c = c >> 1;
		}
	
		crc_table[i] = c;
	}
}

/* bufferのCRCコードを計算 */  
static unsigned int crc32(unsigned int crc,unsigned char *buffer, unsigned int size)
{
	unsigned int i;
	for (i = 0; i < size; i++) {
		crc = crc_table[(crc ^ buffer[i]) & 0xff] ^ (crc >> 8);
	}
	return crc;
}

void usage(char *command)
{
    printf("usage :%s server_ip port_number\n", command);
    exit(0);
}


int main(int argc, char** argv)
{
	long int id = 1;
	unsigned int crc32_buf;
	char receive_file_name[256]= "recv_";
	struct sockaddr_in server_addr;		/* server address */
	socklen_t server_addr_length;		/*  */
	int client_socket_fd;
	char file_name[FILE_NAME_MAX_SIZE + 1];
	char buffer[BUFFER_SIZE];
	FILE *fp = NULL;
	int recv_len = 0;
	struct timeval tv;
	fd_set read_fds;


	if (argc != 3) {
		usage(argv[0]);
	}
    

	bzero(&server_addr, sizeof(server_addr));
	server_addr.sin_family = AF_INET;			/*  */
	server_addr.sin_port = htons(atoi(argv[2]));		/*  */
	//server_addr.sin_addr.s_addr = inet_addr("43.31.77.14");	/* ifconfigの結果を設定しなさい */
	inet_pton(AF_INET, argv[1], &server_addr.sin_addr);	/*  */
	server_addr_length = sizeof(server_addr);		/*  */
	
	/* create socket */
	client_socket_fd = socket(AF_INET, SOCK_DGRAM, 0);	/* SOCK_DGRAM: UDP, SOCK_STREAM: TCP */
	if(client_socket_fd < 0) {
		printf("[Client]create socket failed\n"); 
		exit(1);
	}
	
	/* create crc32 table */
	init_crc_table();
	
	/* input file name to buffer */
	bzero(file_name, FILE_NAME_MAX_SIZE + 1);
	printf("[Client]please input the file name: ");
	scanf("%s", file_name);
	bzero(buffer, BUFFER_SIZE);
	strncpy(buffer, file_name, strlen(file_name) > BUFFER_SIZE ? BUFFER_SIZE : strlen(file_name));
	
	/* send file name to server */
	if(sendto(client_socket_fd, buffer, BUFFER_SIZE, 0, (struct sockaddr*)&server_addr, server_addr_length) < 0) {
		printf("[Client]send file name failed\n");
		exit(1);
	} else {
		printf("[Clinet]send file name ok\n"); 
	}
	
	/* open new file */
	fp = fopen(strcat(receive_file_name, file_name), "w");
	if(NULL == fp) {
		printf("[Client]file:\t%s can not create open to write\n", file_name);
		exit(1);
	} else {
		printf("[Clinet]file:\t%s create open ok\n", receive_file_name);  
	}

	/* serverから受信し、fileに書き込む */
	while(1) {
		pack_info_t pack_info;

wait_server:
		FD_ZERO(&read_fds);
		FD_SET(client_socket_fd, &read_fds);
		tv.tv_sec = 3;
		tv.tv_usec = 0;
		
		select(client_socket_fd+1, &read_fds, NULL, NULL, &tv);		/* */
		if (FD_ISSET(client_socket_fd, &read_fds)) {
		        if((recv_len = recvfrom(client_socket_fd, (char*)&data, sizeof(data), 0, (struct sockaddr*)&server_addr, &server_addr_length)) > 0) {	/* 受信中 */
			        printf("[Client]recv_len =%d\n", recv_len);
			        crc32_buf = crc32(crc,data.buf, sizeof(data));
			
			        printf("-------------------------\n");
			        printf("[Client]data.head.id=%ld\n", data.head.id);
			        printf("[Clinet]id=%ld\n", id);
			
			        if(data.head.id == id) {	/* もし送り直したpackageじゃなかったら、正常受信だったら */
				        printf("[Client]crc32_buf=0x%x\n", crc32_buf);        
				        printf("[Client]data.head.crc32val=0x%x\n", data.head.crc32val);
				        //printf("data.buf=%s\n",data.buf);
				
				        /* データの正確性を確認 */
				        if(data.head.crc32val == crc32_buf) {
					        printf("receive data success\n");
					        pack_info.id = data.head.id;
					        pack_info.buf_size = data.head.buf_size;	/* fileの中の有効Byte数、fileに書き込む時使う*/
					        ++id;				/* Packageを正しく受信できたので、次のPackageの受信用に++ */
					
					        /* send confirm information */
					        if(sendto(client_socket_fd, (char*)&pack_info, sizeof(pack_info_t), 0, (struct sockaddr*)&server_addr, server_addr_length) < 0) {
						        printf("send confirm information failed!");
					        }
					
					        /* write to file */
					        if(fwrite(data.buf, sizeof(char), data.head.buf_size, fp) < data.head.buf_size) {
						        printf("file:\t%s write failed\n", file_name);
						        break;
					        }
				        } else {	/* error packageは、serverに送り直すように要求 */
					        pack_info.id = data.head.id;
					        pack_info.buf_size = data.head.buf_size;
					        pack_info.err_flag = 1;
					
					        printf("recv data error, need to send again\n");
					
					        /* resend confirm information */
					        if(sendto(client_socket_fd, (char*)&pack_info, sizeof(pack_info_t), 0, (struct sockaddr*)&server_addr, server_addr_length) < 0) {
						        printf("resend confirm information failed!");
					        }
				        }
			        } else if(data.head.id < id) {	/* 送り直したpackageだったら */
				        pack_info.id = data.head.id;
				        pack_info.buf_size = data.head.buf_size;
				        pack_info.err_flag = 0;	/* clear error package flag */
				
				        printf("data.head.id < id\n");
				
				        /* send confirm information */
				        if(sendto(client_socket_fd, (char*)&pack_info, sizeof(pack_info_t), 0, (struct sockaddr*)&server_addr, server_addr_length) < 0) {
					        printf("send confirm information failed!");
				        }
			        }
		        } else {	/* 受信し終わったので、終了 */
			        printf("recvfrom() over...\n");
			        break;
		        }
		} else {
		      printf("[Client]timeout, server is busy??? I'm waiting...\n");
		       goto wait_server;
		}
		
	}
	
	
	printf("[Client]receive file:\t%s from server ip successful!\n", file_name); 
	fclose(fp); 
	close(client_socket_fd); 
	
	return 0; 
}
